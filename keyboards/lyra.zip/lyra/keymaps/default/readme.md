# The default keymap for lyra
